package com.example.newsworld;


import com.example.newsworld.Models.NewsHeadlines;

public interface SelectListener {
    void  onNewsClicked(NewsHeadlines headlines);
}
