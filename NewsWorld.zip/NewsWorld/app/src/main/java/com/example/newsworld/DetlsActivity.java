package com.example.newsworld;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.newsworld.Models.NewsHeadlines;
import com.squareup.picasso.Picasso;

public class DetlsActivity extends AppCompatActivity {
      NewsHeadlines headlines;
      TextView textView_title,textView_author,textView_time
              ,textView_detail,textView_content;
      ImageView imageView_news_detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detls);
        textView_title = findViewById(R.id.text_detail_title);
        textView_author = findViewById(R.id.text_detail_author);
        textView_time = findViewById(R.id.text_detail_time);
        textView_detail = findViewById(R.id.text_detail_detail);
        textView_content=findViewById(R.id.text_detail_content);
        imageView_news_detail = findViewById(R.id.img_detail_news);
        headlines = (NewsHeadlines) getIntent().getSerializableExtra("data");
        textView_title.setText(headlines.getTitle());
        textView_author.setText(headlines.getAuthor());
        textView_time.setText(headlines.getPublishedAt());
        textView_detail.setText(headlines.getDescription());
        textView_content.setText(headlines.getContent());
        Picasso.get().load(headlines.getUrlToImage())
                .into(imageView_news_detail);
    }
}